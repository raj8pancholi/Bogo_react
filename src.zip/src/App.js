// import logo from './logo.svg';
import './App.css';


// import css part
import "./assets/css/style.css";
import "./assets/css/responsive.css";


// import navigation .
import Navigation from './routes/Navigation';

function App() {
  return (
    <div className="App">
      
        {/* <Header /> */}
        <Navigation />
        {/* <Footer /> */}
    </div>
  );
}

export default App;
