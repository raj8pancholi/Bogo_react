import React from 'react';

export default function VerifyOtpImage() {
  return (
    <div className="col-md-6 user_img_row">
      <img
        src="/images/merchant_reg_img.jpg"
        alt=""
      />
    </div>
  );
}
