import React from 'react'

export default function Tab6() {
  return (
    <>
        <div id="tab6" className="tab-content1">
            <div className="row">
                <div className="col-6">
                <div className="offerLabel">
                    <div className="offerlabelbox">Buy1 Get1</div>
                </div>
                <div className="campaign_offer_type">
                    <div className="offerType1">
                    <h6 className="me-1">Buy1:</h6>
                    <h6>sushi Platter</h6>
                    </div>
                    <div className="offerType2">
                    <h6 className="me-1">Get1:</h6>
                    <h6>sushi Platter</h6>
                    </div>
                </div>
                <div className="influencer_appli"></div>
                </div>
                <div className="col-6">
                <div className="public_nowCampaign_row">
                    <button tyu="" className="public_nowCampaign_box">
                    Publish Now
                    </button>
                </div>
                </div>
            </div>
            {/*  */}
            <div className="row mt-3">
                <div className="col-6">
                <div className="offerLabel">
                    <div className="offerlabelbox">Buy1 Get1</div>
                </div>
                <div className="campaign_offer_type">
                    <div className="offerType1">
                    <h6 className="me-1">Buy1:</h6>
                    <h6>sushi Platter</h6>
                    </div>
                    <div className="offerType2">
                    <h6 className="me-1">Get1:</h6>
                    <h6>sushi Platter</h6>
                    </div>
                </div>
                <div className="influencer_appli"></div>
                </div>
                <div className="col-6">
                <div className="public_nowCampaign_row">
                    <button tyu="" className="public_nowCampaign_box">
                    Publish Now
                    </button>
                </div>
                </div>
            </div>
        </div>

    </>
  )
}
