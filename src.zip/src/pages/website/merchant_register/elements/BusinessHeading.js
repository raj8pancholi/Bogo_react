import React from 'react'

export default function BusinessHeading() {
  return (
    <>
    <div className="Business_hedding_section">
      <h1>Business Information</h1>
      <p>Type Your Business Name</p>
    </div>
    </>
  )
}
