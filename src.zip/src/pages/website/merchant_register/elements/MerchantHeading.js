import React from 'react'

export default function MerchantHeading() {
  return (
    <>
    <div className="merchant_hedding">
      <h1>Merchant Registration</h1>
      <p>What type of business are you?</p>
    </div>
    </>
  )
}
