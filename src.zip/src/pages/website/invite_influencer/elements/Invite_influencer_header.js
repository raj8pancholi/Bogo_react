import React from 'react'

function Invite_influencer_header() {
    return (
        <>
            <div className="campaign-header">
                <div className="container">

                    <div className="inner-hero-section-short">
                        <h2 data-aos="flip-up" className="aos-init aos-animate">
                            Invite Influencers
                        </h2>
                    </div>

                </div>
            </div>

        </>
    )
}

export default Invite_influencer_header