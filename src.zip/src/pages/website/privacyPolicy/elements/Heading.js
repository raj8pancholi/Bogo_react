import React from 'react'

export default function Heading() {
  return (
    <>
    <div className="terms-condition-header">
        <div className="container">
            <div className="terms-condition-heading">
                <h1>Privacy Policy</h1>
            </div>
        </div>
    </div> 
    </>
  )
}
