import React from 'react';

export default function FinePrint() {
  return (
    <div className="fine_print">
      {/* ... fine print components ... */}
        <h4>FINE PRINT</h4>
        <div className="fine_print_outbox">
            <span>
            This Buy 1 Get 1 Voucher excludes all Family-sized Platters.
            </span>
        </div>
    </div>
  );
}
