import React from 'react'

export default function AbmassadorsHeading() {
  return (
    <>
        <div className="campaign-header">
            <div className="container">
                
                <div className="inner-hero-section-short">
                <h2 >
                    Create Your Campaign
                </h2>
                <span>This is how your campaign will appear to customers</span>
                </div>
            </div>
        </div>
    </>
  )
}
