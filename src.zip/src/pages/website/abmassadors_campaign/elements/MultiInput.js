// import { Multiselect } from 'multiselect-react-dropdown';

// this.state = {
//     options: [{name: 'Srigar', id: 1},{name: 'Sam', id: 2}]
// };



// <Multiselect
// options={this.state.options} // Options to display in the dropdown
// selectedValues={this.state.selectedValue} // Preselected value to persist in dropdown
// onSelect={this.onSelect} // Function will trigger on select event
// onRemove={this.onRemove} // Function will trigger on remove event
// displayValue="name" // Property name to display in the dropdown options
// />