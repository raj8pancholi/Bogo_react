// import React from 'react';


// const DashboardHeader = () => (



//   <div className="deshboard-header">
//     <div className="container">

//       <div className="deshboard-header-heading">
//         <div className="campaign_card_row">
//           <div className="campaign_card_text">
//             <h3>Create and launch your campaign</h3>
//             <span>
//               <a href="/" className="play_iconBtn">
//                 <img src="/assets/img/play_icon.png" alt='' className="img-fluid" />
//                 <img src="/img/play_icon.png" alt='' className="img-fluid mr-2" />
//                 Watch how it works
//               </a>
//             </span>
//           </div>
//         </div>
//       </div>

//     </div>
//   </div>
// );

// export default DashboardHeader;



import React from 'react';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';

const DashboardHeader = () => {
  const sliderSettings = {
    dots: true, // Show navigation dots
    infinite: true, // Enable infinite loop
    speed: 500, // Transition speed
    slidesToShow: 1, // Number of slides to show at once
    slidesToScroll: 1, // Number of slides to scroll
    // autoplay: true, // Enable autoplay
    autoplaySpeed: 2000, // Autoplay speed
    hoverPause: true, // Pause autoplay on hover
    arrows: false, // Show next/prev buttons
    
  
  };

  return (
    <div className="deshboard-header">
      <div className="container">
        
          <div className="campaignCard_section">
          <Slider {...sliderSettings}>
          <div className="campaign_card_row">
            <div className="campaign_card_text">
              <h3>Create and launch your campaign</h3>
              <span>
                <a href="/" className="play_iconBtn">
                
                  <img src="/img/play_icon.png" alt='' className="img-fluid mr-2" />
                  Watch how it works
                </a>
              </span>
            </div>
          </div>
          {/* Add more slides here */}
          <div className="campaign_card_row">
            <div className="campaign_card_text">
              <h3>Create and launch your campaign</h3>
              <span>
                <a href="/" className="play_iconBtn">
              
                  <img src="/img/play_icon.png" alt='' className="img-fluid mr-2" />
                  Watch how it works
                </a>
              </span>
            </div>
          </div>

          {/*  */}
          <div className="campaign_card_row">
            <div className="campaign_card_text">
              <h3>Create and launch your campaign</h3>
              <span>
                <a href="/" className="play_iconBtn">
                  <img src="/img/play_icon.png" alt='' className="img-fluid mr-2" />
                  Watch how it works
                </a>
              </span>
            </div>
          </div>
        </Slider>
        </div>
      </div>
    </div>
  );
};

export default DashboardHeader;
