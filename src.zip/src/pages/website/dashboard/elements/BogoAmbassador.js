import React from 'react';

const BogoAmbassador = () => (
  <div className="voucher_campaign_row">
    <div className="row">
      <div className="heading_overview">
        <h2>BOGO Ambassador</h2>
      </div>
    </div>
  </div>
);

export default BogoAmbassador;
