import React from 'react'

export default function UserImage() {
  return (
    <>
        <div className="col-md-6 user_img_row">
            <img
                src="/images/merchant_reg_img.jpg"
                alt=""
                className="aos-init aos-animate"
            />
        </div>
    </>
  )
}
