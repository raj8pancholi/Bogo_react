import React from 'react'

export default function InstagramGalleryItem() {
  return (
    <>
    <div className="col-md-4">
        <div className="from_last_images_content_section">
            <img src="/images/Rectangle 224.png" alt="" className="img-fluid" />
        </div>
    </div>
    </>
  )
}
